const f=document.getElementById('quizForm');
const r=document.getElementById('result');
f.addEventListener('submit',e=>{
 e.preventDefault();
 let s=0;
 document.querySelectorAll('[data-score]').forEach(i=>s+=Number(i.value));
 r.innerHTML=s>=13?'🟢 Boa chance':s>=7?'🟡 Chance média':'🔴 Chance baixa';
 r.classList.remove('hidden');
});